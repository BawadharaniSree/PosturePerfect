import { initializeApp, getApps } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getDatabase, ref, get, set, onValue, query, orderByKey, limitToLast } from "firebase/database"

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

// Initialize Firebase
let app
let auth
let database

if (typeof window !== "undefined" && !getApps().length) {
  app = initializeApp(firebaseConfig)
  auth = getAuth(app)
  database = getDatabase(app)
}

// Get the latest sensor data from the global SensorLogs
export const getLatestSensorData = async () => {
  try {
    const sensorRef = ref(database, "SensorLogs")
    const latestDataQuery = query(sensorRef, orderByKey(), limitToLast(1))
    const snapshot = await get(latestDataQuery)

    if (snapshot.exists()) {
      const data = snapshot.val()
      const timestamp = Object.keys(data)[0]
      return {
        timestamp,
        data: data[timestamp],
      }
    }

    return null
  } catch (error) {
    console.error("Error fetching sensor data:", error)
    return null
  }
}

// Subscribe to real-time sensor data updates from the global SensorLogs
export const subscribeSensorData = (callback) => {
  const sensorRef = ref(database, "SensorLogs")
  const latestDataQuery = query(sensorRef, orderByKey(), limitToLast(1))

  return onValue(latestDataQuery, (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.val()
      const timestamp = Object.keys(data)[0]
      callback({
        timestamp,
        data: data[timestamp],
      })
    }
  })
}

// Get sensor data for a specific time range from the global SensorLogs
export const getSensorDataRange = async (startTime, endTime) => {
  try {
    const sensorRef = ref(database, "SensorLogs")
    const snapshot = await get(sensorRef)

    if (snapshot.exists()) {
      const allData = snapshot.val()

      // Filter data based on timestamp range
      const filteredData = Object.entries(allData)
        .filter(([timestamp]) => timestamp >= startTime && timestamp <= endTime)
        .reduce((acc, [timestamp, data]) => {
          acc[timestamp] = data
          return acc
        }, {})

      return filteredData
    }

    return {}
  } catch (error) {
    console.error("Error fetching sensor data range:", error)
    return {}
  }
}

// Process sensor data for history charts
export const processSensorDataForCharts = (sensorData, timeframe) => {
  if (!sensorData || Object.keys(sensorData).length === 0) {
    return []
  }

  // Convert the sensor data to an array of entries
  const entries = Object.entries(sensorData).map(([timestamp, data]) => {
    // Calculate a posture score based on the sensor values
    // This is a simplified algorithm - in a real app, you would use more sophisticated analysis
    const accelZ = data?.Accel_Z || 0
    let score = 0

    if (accelZ > 10.2 && accelZ < 10.6) {
      // Good posture
      score = 85 + Math.random() * 15
    } else if (accelZ > 9.8 && accelZ < 10.2) {
      // Neutral posture
      score = 65 + Math.random() * 20
    } else {
      // Poor posture
      score = 40 + Math.random() * 25
    }

    // Format the timestamp for display
    let time = ""
    const date = new Date(timestamp.replace("_", "T"))

    if (timeframe === "daily") {
      time = date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (timeframe === "weekly") {
      const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
      time = days[date.getDay()]
    } else {
      // Monthly - group by week
      const weekNum = Math.ceil(date.getDate() / 7)
      time = `Week ${weekNum}`
    }

    return {
      time,
      score: Math.round(score),
      timestamp,
    }
  })

  // Group by time label and average the scores
  const groupedData = entries.reduce((acc, entry) => {
    if (!acc[entry.time]) {
      acc[entry.time] = { total: 0, count: 0 }
    }
    acc[entry.time].total += entry.score
    acc[entry.time].count += 1
    return acc
  }, {})

  // Convert grouped data to chart format
  const chartData = Object.entries(groupedData).map(([time, data]) => ({
    time,
    score: Math.round(data.total / data.count),
  }))

  // Sort data by time
  if (timeframe === "daily") {
    // For daily, sort by hour
    chartData.sort((a, b) => {
      const timeA = a.time.split(":").map(Number)
      const timeB = b.time.split(":").map(Number)
      return timeA[0] * 60 + timeA[1] - (timeB[0] * 60 + timeB[1])
    })
  } else if (timeframe === "weekly") {
    // For weekly, sort by day of week
    const dayOrder = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }
    chartData.sort((a, b) => dayOrder[a.time] - dayOrder[b.time])
  } else {
    // For monthly, sort by week number
    chartData.sort((a, b) => {
      const weekA = Number.parseInt(a.time.split(" ")[1])
      const weekB = Number.parseInt(b.time.split(" ")[1])
      return weekA - weekB
    })
  }

  return chartData
}

// Save user profile data
export const saveUserProfile = async (userId, userData) => {
  try {
    const userRef = ref(database, `users/${userId}`)
    await set(userRef, userData)
    return true
  } catch (error) {
    console.error("Error saving user profile:", error)
    return false
  }
}

// Get user profile data
export const getUserProfile = async (userId) => {
  try {
    const userRef = ref(database, `users/${userId}`)
    const snapshot = await get(userRef)

    if (snapshot.exists()) {
      return snapshot.val()
    }

    return null
  } catch (error) {
    console.error("Error fetching user profile:", error)
    return null
  }
}

// Analyze posture based on sensor data
export const analyzePosture = (sensorData) => {
  if (!sensorData || !sensorData.data || sensorData.data.Accel_Z === undefined) return "neutral"

  // This is a simplified analysis - in a real app, you would use more sophisticated algorithms
  const z = sensorData.data.Accel_Z

  if (z > 10.2 && z < 10.6) {
    return "upright"
  } else if (z > 9.8 && z < 10.2) {
    return "neutral"
  } else {
    return "slouched"
  }
}

// Get user streak data
export const getUserStreak = async (userId) => {
  try {
    const streakRef = ref(database, `users/${userId}/streak`)
    const snapshot = await get(streakRef)

    if (snapshot.exists()) {
      return snapshot.val()
    }

    // Default streak data
    return {
      current: 0,
      best: 0,
      lastUpdated: new Date().toISOString(),
      completedDays: [],
    }
  } catch (error) {
    console.error("Error fetching user streak:", error)
    return {
      current: 0,
      best: 0,
      lastUpdated: new Date().toISOString(),
      completedDays: [],
    }
  }
}

// Update user streak
export const updateUserStreak = async (userId, streakData) => {
  try {
    const streakRef = ref(database, `users/${userId}/streak`)
    await set(streakRef, streakData)
    return true
  } catch (error) {
    console.error("Error updating user streak:", error)
    return false
  }
}

export { app, auth, database }
