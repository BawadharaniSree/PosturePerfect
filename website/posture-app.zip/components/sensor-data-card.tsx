import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

interface SensorData {
  timestamp: string
  data: {
    Accel_X?: number
    Accel_Y?: number
    Accel_Z?: number
    Flex_Value?: number
    Gyro_X?: number
    Gyro_Y?: number
    Gyro_Z?: number
  }
}

interface SensorDataCardProps {
  data: SensorData
  loading?: boolean
}

export function SensorDataCard({ data, loading = false }: SensorDataCardProps) {
  // Format timestamp for display
  const formattedTime = data?.timestamp?.replace("_", " ") || "Unknown"

  // Safely access sensor data with fallbacks
  const sensorData = data?.data || {}

  // Helper function to safely format values
  const formatValue = (value: number | undefined): string => {
    return value !== undefined ? value.toFixed(2) : "N/A"
  }

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Sensor Data</CardTitle>
            <CardDescription>Last updated: {loading ? "Loading..." : formattedTime}</CardDescription>
          </div>
          <Activity className={`w-5 h-5 text-blue ${loading ? "animate-pulse" : ""}`} />
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Accelerometer</p>
                <div className="grid grid-cols-3 gap-2">
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Gyroscope</p>
                <div className="grid grid-cols-3 gap-2">
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                </div>
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Flex Sensor</p>
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Accelerometer</p>
                <div className="grid grid-cols-3 gap-2">
                  <DataPoint label="X" value={formatValue(sensorData.Accel_X)} />
                  <DataPoint label="Y" value={formatValue(sensorData.Accel_Y)} />
                  <DataPoint label="Z" value={formatValue(sensorData.Accel_Z)} />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Gyroscope</p>
                <div className="grid grid-cols-3 gap-2">
                  <DataPoint label="X" value={formatValue(sensorData.Gyro_X)} />
                  <DataPoint label="Y" value={formatValue(sensorData.Gyro_Y)} />
                  <DataPoint label="Z" value={formatValue(sensorData.Gyro_Z)} />
                </div>
              </div>
            </div>
            <div className="mt-4 space-y-1">
              <p className="text-xs text-muted-foreground">Flex Sensor</p>
              <DataPoint label="Value" value={sensorData.Flex_Value?.toString() || "N/A"} />
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}

function DataPoint({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-2 text-center bg-muted rounded-md">
      <p className="text-xs font-medium">{label}</p>
      <p className="text-sm">{value}</p>
    </div>
  )
}
