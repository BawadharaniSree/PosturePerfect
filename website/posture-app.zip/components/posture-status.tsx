import { Smile, Meh, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface PostureStatusProps {
  posture: "upright" | "slouched" | "neutral"
}

export function PostureStatus({ posture }: PostureStatusProps) {
  const statusMap = {
    upright: {
      icon: Smile,
      text: "Great posture!",
      color: "bg-mint text-navy",
      description: "Keep it up! Your spine thanks you.",
    },
    neutral: {
      icon: Meh,
      text: "Okay posture",
      color: "bg-blue text-navy",
      description: "Try to sit more upright for better alignment.",
    },
    slouched: {
      icon: AlertTriangle,
      text: "Poor posture",
      color: "bg-orange-200 text-orange-800",
      description: "Straighten your back and adjust your position.",
    },
  }

  const status = statusMap[posture]
  const Icon = status.icon

  return (
    <div className="flex flex-col items-center gap-2">
      <Badge className={`px-3 py-1 flex items-center gap-1.5 ${status.color}`}>
        <Icon className="w-4 h-4" />
        {status.text}
      </Badge>
      <p className="text-sm text-center text-muted-foreground">{status.description}</p>
    </div>
  )
}
