import type { SVGProps } from "react"

interface PostureAvatarProps extends SVGProps<SVGSVGElement> {
  posture: "upright" | "slouched" | "neutral"
}

export function PostureAvatar({ posture = "neutral", ...props }: PostureAvatarProps) {
  // Different posture positions
  const postureStyles = {
    upright: {
      spine: "M50 30 L50 70",
      head: "translate(0, 0) rotate(0)",
      shoulders: "M35 40 L65 40",
    },
    slouched: {
      spine: "M50 30 Q45 50 50 70",
      head: "translate(0, 2) rotate(5deg)",
      shoulders: "M35 40 Q50 45 65 40",
    },
    neutral: {
      spine: "M50 30 L50 70",
      head: "translate(0, 0) rotate(0)",
      shoulders: "M35 40 L65 40",
    },
  }

  const currentStyle = postureStyles[posture]

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 100"
      width="80"
      height="80"
      fill="none"
      stroke="#1D3557"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="50" cy="20" r="10" fill="#BDE0C0" />
      <g transform={currentStyle.head}>
        <circle cx="50" cy="20" r="10" fill="#BDE0C0" />
      </g>
      <path d={currentStyle.spine} stroke="#1D3557" strokeWidth="3" />
      <path d={currentStyle.shoulders} stroke="#1D3557" strokeWidth="3" />
      <path d="M35 40 L30 60" stroke="#1D3557" strokeWidth="2" />
      <path d="M65 40 L70 60" stroke="#1D3557" strokeWidth="2" />
      <path d="M30 60 L30 80" stroke="#1D3557" strokeWidth="2" />
      <path d="M70 60 L70 80" stroke="#1D3557" strokeWidth="2" />
    </svg>
  )
}
