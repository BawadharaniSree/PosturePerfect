"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Logo } from "@/components/logo"
import { Home, BookOpen, BarChart2, User, Menu } from "lucide-react"

export function Navbar() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const routes = [
    { name: "Home", path: "/dashboard", icon: Home },
    { name: "Tips", path: "/tips", icon: BookOpen },
    { name: "History", path: "/history", icon: BarChart2 },
    { name: "Profile", path: "/profile", icon: User },
  ]

  const isActive = (path: string) => pathname === path

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex items-center justify-between h-14">
        <Link href="/dashboard" className="flex items-center gap-2">
          <Logo className="w-8 h-8" />
          <span className="font-semibold text-navy">Posture Perfect</span>
        </Link>

        {/* Mobile Menu */}
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="w-5 h-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <Link href="/dashboard" className="flex items-center gap-2 mb-8">
              <Logo className="w-8 h-8" />
              <span className="font-semibold text-navy">Posture Perfect</span>
            </Link>
            <nav className="flex flex-col gap-4">
              {routes.map((route) => {
                const Icon = route.icon
                return (
                  <Link
                    key={route.path}
                    href={route.path}
                    className={`flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors ${
                      isActive(route.path) ? "bg-blue/20 text-navy font-medium" : "hover:bg-muted"
                    }`}
                    onClick={() => setOpen(false)}
                  >
                    <Icon className="w-4 h-4" />
                    {route.name}
                  </Link>
                )
              })}
            </nav>
          </SheetContent>
        </Sheet>

        {/* Desktop Menu */}
        <nav className="hidden md:flex items-center gap-6">
          {routes.map((route) => {
            const Icon = route.icon
            return (
              <Link
                key={route.path}
                href={route.path}
                className={`flex items-center gap-2 text-sm transition-colors ${
                  isActive(route.path) ? "text-navy font-medium" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                {route.name}
              </Link>
            )
          })}
        </nav>
      </div>
    </header>
  )
}
