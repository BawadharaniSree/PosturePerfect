import type { SVGProps } from "react"

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 100"
      fill="none"
      stroke="#1D3557"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="50" cy="50" r="45" fill="#A8DADC" opacity="0.8" />
      <path d="M50 20 L50 80" stroke="#1D3557" strokeWidth="3" strokeDasharray="1 3" />
      <circle cx="50" cy="30" r="10" fill="#BDE0C0" />
      <path d="M35 45 Q50 40 65 45 L65 70 Q50 75 35 70 Z" fill="#F1FAEE" stroke="#1D3557" />
      <path d="M40 55 L45 65 L50 60 L55 65 L60 55" stroke="#1D3557" strokeWidth="2" fill="none" />
    </svg>
  )
}
