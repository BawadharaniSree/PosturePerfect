import { Star } from "lucide-react"

interface PostureStreakProps {
  streak: number
  completedDays?: string[]
}

export function PostureStreak({ streak, completedDays = [] }: PostureStreakProps) {
  // Generate an array of days for the week
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

  // Get current day of week (0 = Sunday, 1 = Monday, etc.)
  const today = new Date().getDay()

  // Convert to our format (0 = Monday, 6 = Sunday)
  const todayIndex = today === 0 ? 6 : today - 1

  // Calculate how many days in the week we've completed
  const completedCount = Math.min(completedDays.length, 7)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center gap-2 p-3 bg-blue/20 rounded-lg">
        <Star className="w-5 h-5 text-blue fill-blue" />
        <p className="text-lg font-medium text-navy">{streak} Day Streak</p>
      </div>

      <div className="flex justify-between">
        {days.map((day, index) => {
          // Check if this day is completed
          const isCompleted = index < completedCount

          // Check if this day is today
          const isToday = index === todayIndex

          // Check if this day is in the future
          const isFuture = index > todayIndex

          return (
            <div key={day} className="flex flex-col items-center gap-1">
              <div
                className={`w-8 h-8 flex items-center justify-center rounded-full ${
                  isCompleted
                    ? "bg-mint text-navy"
                    : isFuture
                      ? "bg-muted text-muted-foreground"
                      : "bg-muted text-muted-foreground"
                } ${isToday ? "ring-2 ring-blue" : ""}`}
              >
                {isCompleted ? <Star className="w-4 h-4 fill-current" /> : <span className="text-xs">{index + 1}</span>}
              </div>
              <span className="text-xs">{day}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
