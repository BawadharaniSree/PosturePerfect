import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// This function can be marked `async` if using `await` inside
export function middleware(request: NextRequest) {
  // Check if the user is accessing a protected route
  const protectedPaths = ["/dashboard", "/profile", "/history", "/tips", "/onboarding"]
  const path = request.nextUrl.pathname

  // Check if the current path is a protected path
  const isProtectedPath = protectedPaths.some(
    (protectedPath) => path === protectedPath || path.startsWith(`${protectedPath}/`),
  )

  // For protected paths, we'll check for authentication in the client component
  // This middleware just ensures that unauthenticated users are redirected to the auth page
  // when they try to access protected routes directly via URL

  // In a real app, you would check for a session cookie here
  // For now, we'll just redirect to the auth page for all protected routes
  // The actual auth check will happen in the client components

  if (isProtectedPath) {
    // In a real implementation, you would check for a valid session cookie here
    // For now, we'll just let the client-side auth check handle it
    return NextResponse.next()
  }

  return NextResponse.next()
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: ["/dashboard/:path*", "/profile/:path*", "/history/:path*", "/tips/:path*", "/onboarding/:path*"],
}
