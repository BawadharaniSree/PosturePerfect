"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Logo } from "@/components/logo"
import { Badge } from "@/components/ui/badge"
import { CheckCircle } from "lucide-react"
import { auth, saveUserProfile } from "@/lib/firebase"
import { onAuthStateChanged } from "firebase/auth"

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [showBadge, setShowBadge] = useState(false)
  const [loading, setLoading] = useState(false)
  const [userId, setUserId] = useState<string | null>(null)
  const totalSteps = 3

  // Form state
  const [gender, setGender] = useState("")
  const [age, setAge] = useState("")
  const [height, setHeight] = useState("")
  const [weight, setWeight] = useState("")
  const [workType, setWorkType] = useState("")
  const [dailyHours, setDailyHours] = useState("")

  // Check if user is authenticated
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUserId(user.uid)
      } else {
        // Redirect to login if not authenticated
        router.push("/auth")
      }
    })

    return () => unsubscribe()
  }, [router])

  const handleNext = async () => {
    if (step < totalSteps) {
      setStep(step + 1)
    } else {
      setLoading(true)

      // Save user profile data to Firebase
      if (userId) {
        try {
          const userData = {
            gender,
            age: Number.parseInt(age),
            height: Number.parseInt(height),
            weight: Number.parseInt(weight),
            workType,
            dailyHours,
            onboardingCompleted: true,
            createdAt: new Date().toISOString(),
          }

          await saveUserProfile(userId, userData)

          // Show completion badge
          setShowBadge(true)

          // Redirect after showing badge
          setTimeout(() => {
            router.push("/dashboard")
          }, 2000)
        } catch (error) {
          console.error("Error saving profile:", error)
        } finally {
          setLoading(false)
        }
      }
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-4 bg-beige">
      <div className="w-full max-w-md space-y-6 fade-in">
        <div className="flex flex-col items-center">
          <Logo className="w-16 h-16" />
          <h1 className="mt-2 text-xl font-semibold text-navy">Let's Get Started</h1>
          <p className="text-sm text-muted-foreground">Tell us a bit about yourself</p>
        </div>

        <Card className="w-full shadow-md">
          <CardHeader>
            <CardTitle className="text-lg text-navy">Profile Setup</CardTitle>
            <CardDescription>
              Step {step} of {totalSteps}
            </CardDescription>
            <Progress value={(step / totalSteps) * 100} className="h-2 mt-2" />
          </CardHeader>

          <CardContent>
            {step === 1 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={gender} onValueChange={setGender}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="non-binary">Non-binary</SelectItem>
                      <SelectItem value="prefer-not">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    min="1"
                    max="120"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                  />
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    min="50"
                    max="250"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    min="20"
                    max="300"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                  />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="workType">Work Type</Label>
                  <Select value={workType} onValueChange={setWorkType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select work type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desk">Desk Job</SelectItem>
                      <SelectItem value="standing">Standing Job</SelectItem>
                      <SelectItem value="physical">Physical Labor</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dailyHours">Hours at desk per day</Label>
                  <Select value={dailyHours} onValueChange={setDailyHours}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select hours" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0-2">0-2 hours</SelectItem>
                      <SelectItem value="3-5">3-5 hours</SelectItem>
                      <SelectItem value="6-8">6-8 hours</SelectItem>
                      <SelectItem value="8+">8+ hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {showBadge && (
              <div className="flex flex-col items-center justify-center py-6 space-y-4 animate-in fade-in">
                <div className="p-2 rounded-full bg-mint">
                  <CheckCircle className="w-12 h-12 text-navy" />
                </div>
                <Badge className="px-3 py-1 text-sm bg-blue text-navy">Profile Complete!</Badge>
                <p className="text-sm text-center text-muted-foreground">Your profile has been set up successfully!</p>
              </div>
            )}
          </CardContent>

          {!showBadge && (
            <CardFooter>
              <Button onClick={handleNext} className="w-full bg-blue hover:bg-blue/90 text-navy" disabled={loading}>
                {loading ? "Saving..." : step < totalSteps ? "Next" : "Complete Setup"}
              </Button>
            </CardFooter>
          )}
        </Card>
      </div>
    </div>
  )
}
