"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PostureChart } from "@/components/posture-chart"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, TrendingUp, Award } from "lucide-react"
import { getSensorDataRange, processSensorDataForCharts } from "@/lib/firebase"
import { Skeleton } from "@/components/ui/skeleton"

export default function HistoryPage() {
  const [timeframe, setTimeframe] = useState("daily")
  const [loading, setLoading] = useState(true)
  const [chartData, setChartData] = useState({
    daily: [],
    weekly: [],
    monthly: [],
  })

  // Fetch sensor data on component mount and when timeframe changes
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // Get current date
        const now = new Date()
        let startTime, endTime

        // Set time range based on selected timeframe
        if (timeframe === "daily") {
          // Last 24 hours
          startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString().replace("T", "_").split(".")[0]
          endTime = now.toISOString().replace("T", "_").split(".")[0]
        } else if (timeframe === "weekly") {
          // Last 7 days
          startTime = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().replace("T", "_").split(".")[0]
          endTime = now.toISOString().replace("T", "_").split(".")[0]
        } else {
          // Last 30 days
          startTime = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().replace("T", "_").split(".")[0]
          endTime = now.toISOString().replace("T", "_").split(".")[0]
        }

        // Fetch data from Firebase
        const sensorData = await getSensorDataRange(startTime, endTime)

        // Process data for chart
        const processedData = processSensorDataForCharts(sensorData, timeframe)

        // Update chart data
        setChartData((prev) => ({
          ...prev,
          [timeframe]: processedData,
        }))
      } catch (error) {
        console.error("Error fetching history data:", error)

        // Use mock data if fetch fails
        setChartData((prev) => ({
          ...prev,
          [timeframe]: getMockDataForTimeframe(timeframe),
        }))
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [timeframe])

  // Get mock data for different timeframes (fallback)
  const getMockDataForTimeframe = (timeframe) => {
    switch (timeframe) {
      case "daily":
        return [
          { time: "8 AM", score: 85 },
          { time: "10 AM", score: 70 },
          { time: "12 PM", score: 90 },
          { time: "2 PM", score: 65 },
          { time: "4 PM", score: 80 },
          { time: "6 PM", score: 75 },
        ]
      case "weekly":
        return [
          { time: "Mon", score: 75 },
          { time: "Tue", score: 82 },
          { time: "Wed", score: 78 },
          { time: "Thu", score: 85 },
          { time: "Fri", score: 80 },
          { time: "Sat", score: 90 },
          { time: "Sun", score: 88 },
        ]
      case "monthly":
        return [
          { time: "Week 1", score: 78 },
          { time: "Week 2", score: 82 },
          { time: "Week 3", score: 85 },
          { time: "Week 4", score: 88 },
        ]
      default:
        return []
    }
  }

  const getAverageScore = (data) => {
    if (!data || data.length === 0) return 0
    const sum = data.reduce((acc, item) => acc + item.score, 0)
    return Math.round(sum / data.length)
  }

  const currentData = chartData[timeframe] || []
  const averageScore = getAverageScore(currentData)

  // Get description text based on timeframe
  const getTimeframeDescription = () => {
    const now = new Date()

    if (timeframe === "daily") {
      return now.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
    } else if (timeframe === "weekly") {
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
      return `${oneWeekAgo.toLocaleDateString("en-US", { month: "long", day: "numeric" })} - ${now.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}`
    } else {
      return now.toLocaleDateString("en-US", { month: "long", year: "numeric" })
    }
  }

  return (
    <div className="space-y-6 page-transition">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold tracking-tight text-navy">Posture History</h1>
        <p className="text-muted-foreground">Track your posture trends over time</p>
      </div>

      <Tabs defaultValue="daily" onValueChange={setTimeframe}>
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="space-y-6">
          <PostureChartCard
            title="Today's Posture"
            description={getTimeframeDescription()}
            data={chartData.daily}
            icon={Clock}
            loading={loading && timeframe === "daily"}
          />
        </TabsContent>

        <TabsContent value="weekly" className="space-y-6">
          <PostureChartCard
            title="This Week's Posture"
            description={getTimeframeDescription()}
            data={chartData.weekly}
            icon={Calendar}
            loading={loading && timeframe === "weekly"}
          />
        </TabsContent>

        <TabsContent value="monthly" className="space-y-6">
          <PostureChartCard
            title="This Month's Posture"
            description={getTimeframeDescription()}
            data={chartData.monthly}
            icon={Calendar}
            loading={loading && timeframe === "monthly"}
          />
        </TabsContent>
      </Tabs>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Average Score</CardTitle>
              <TrendingUp className="w-5 h-5 text-blue" />
            </div>
            <CardDescription>
              {timeframe === "daily" ? "Today" : timeframe === "weekly" ? "This week" : "This month"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center p-6">
                <Skeleton className="w-32 h-32 rounded-full" />
              </div>
            ) : (
              <div className="flex items-center justify-center p-6">
                <div className="relative flex items-center justify-center w-32 h-32 rounded-full bg-blue/20">
                  <div className="absolute inset-2 flex items-center justify-center rounded-full bg-background">
                    <div className="text-3xl font-bold text-navy">{averageScore}</div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Achievements</CardTitle>
              <Award className="w-5 h-5 text-blue" />
            </div>
            <CardDescription>Your posture milestones</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-mint/20">
                <Badge className="bg-mint text-navy">New</Badge>
                <div>
                  <p className="font-medium text-navy">3-Day Streak</p>
                  <p className="text-xs text-muted-foreground">Maintained good posture for 3 days</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-lg bg-blue/20">
                <Badge className="bg-blue text-navy">Unlocked</Badge>
                <div>
                  <p className="font-medium text-navy">Posture Pro</p>
                  <p className="text-xs text-muted-foreground">Achieved 80+ score for a full day</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

interface PostureChartCardProps {
  title: string
  description: string
  data: { time: string; score: number }[]
  icon: React.ElementType
  loading?: boolean
}

function PostureChartCard({ title, description, data, icon: Icon, loading = false }: PostureChartCardProps) {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{title}</CardTitle>
          <Icon className="w-5 h-5 text-blue" />
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] w-full flex items-center justify-center">
            <Skeleton className="h-[250px] w-full" />
          </div>
        ) : (
          <PostureChart data={data} />
        )}
      </CardContent>
    </Card>
  )
}
