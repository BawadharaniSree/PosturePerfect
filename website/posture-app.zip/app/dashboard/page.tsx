"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PostureAvatar } from "@/components/posture-avatar"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Clock, TrendingUp } from "lucide-react"
import { PostureStatus } from "@/components/posture-status"
import { SensorDataCard } from "@/components/sensor-data-card"
import { PostureStreak } from "@/components/posture-streak"
import {
  getLatestSensorData,
  subscribeSensorData,
  analyzePosture,
  getUserStreak,
  updateUserStreak,
  auth,
} from "@/lib/firebase"
import { onAuthStateChanged } from "firebase/auth"

// Fallback data in case Firebase connection fails
const fallbackSensorData = {
  timestamp: "2025-04-29_12:23:33",
  data: {
    Accel_X: 0.09577,
    Accel_Y: -0.06464,
    Accel_Z: 10.43633,
    Flex_Value: 0,
    Gyro_X: -0.0445,
    Gyro_Y: 0.03171,
    Gyro_Z: 0.0445,
  },
}

export default function DashboardPage() {
  const [currentPosture, setCurrentPosture] = useState<"upright" | "slouched" | "neutral">("neutral")
  const [sensorData, setSensorData] = useState(fallbackSensorData)
  const [streak, setStreak] = useState(0)
  const [completedDays, setCompletedDays] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [userId, setUserId] = useState<string | null>(null)

  // Check authentication and get user ID
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUserId(user.uid)
      }
    })

    return () => unsubscribe()
  }, [])

  // Fetch user streak data
  useEffect(() => {
    const fetchUserStreak = async () => {
      if (!userId) return

      try {
        const streakData = await getUserStreak(userId)
        setStreak(streakData.current || 0)
        setCompletedDays(streakData.completedDays || [])
      } catch (error) {
        console.error("Error fetching user streak:", error)
      }
    }

    if (userId) {
      fetchUserStreak()
    }
  }, [userId])

  // Fetch initial sensor data and subscribe to updates
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const latestData = await getLatestSensorData()
        if (latestData && latestData.data) {
          setSensorData(latestData)
          const posture = analyzePosture(latestData)
          setCurrentPosture(posture as "upright" | "slouched" | "neutral")
        }
      } catch (error) {
        console.error("Error fetching initial sensor data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchInitialData()

    // Subscribe to real-time updates
    const unsubscribe = subscribeSensorData((newData) => {
      if (newData && newData.data) {
        setSensorData(newData)
        const posture = analyzePosture(newData)
        setCurrentPosture(posture as "upright" | "slouched" | "neutral")
      }
    })

    // Cleanup subscription on unmount
    return () => {
      if (unsubscribe) unsubscribe()
    }
  }, [])

  // Update user streak based on posture
  useEffect(() => {
    const updateStreak = async () => {
      if (!userId || loading) return

      try {
        // Get current streak data
        const currentStreakData = await getUserStreak(userId)

        // Get today's date in YYYY-MM-DD format
        const today = new Date().toISOString().split("T")[0]

        // Check if we already updated the streak today
        if (currentStreakData.lastUpdated && currentStreakData.lastUpdated.startsWith(today)) {
          return
        }

        // Update streak based on current posture
        let newStreak = currentStreakData.current
        let newCompletedDays = [...(currentStreakData.completedDays || [])]

        if (currentPosture === "upright") {
          // Increment streak for good posture
          newStreak += 1

          // Add today to completed days if not already there
          if (!newCompletedDays.includes(today)) {
            newCompletedDays.push(today)
          }
        } else {
          // Reset streak for bad posture
          newStreak = 0
        }

        // Update best streak if current is higher
        const newBest = Math.max(currentStreakData.best || 0, newStreak)

        // Keep only the last 7 days in completed days
        if (newCompletedDays.length > 7) {
          newCompletedDays = newCompletedDays.slice(-7)
        }

        // Update streak data in Firebase
        const updatedStreakData = {
          current: newStreak,
          best: newBest,
          lastUpdated: new Date().toISOString(),
          completedDays: newCompletedDays,
        }

        await updateUserStreak(userId, updatedStreakData)

        // Update local state
        setStreak(newStreak)
        setCompletedDays(newCompletedDays)
      } catch (error) {
        console.error("Error updating streak:", error)
      }
    }

    // Only update streak if we have user ID and posture data
    if (userId && !loading) {
      updateStreak()
    }
  }, [userId, currentPosture, loading])

  return (
    <div className="space-y-6 page-transition">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold tracking-tight text-navy">Dashboard</h1>
        <p className="text-muted-foreground">Monitor your posture in real-time and track your progress</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Current Posture</CardTitle>
            <CardDescription>Real-time posture analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center gap-4">
              <PostureAvatar posture={currentPosture} className="w-32 h-32" />
              <PostureStatus posture={currentPosture} />
            </div>
          </CardContent>
        </Card>

        <SensorDataCard data={sensorData} loading={loading} />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Posture Streak</CardTitle>
            <CardDescription>Your daily posture achievements</CardDescription>
          </CardHeader>
          <CardContent>
            <PostureStreak streak={streak} completedDays={completedDays} />
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Recent Tips</CardTitle>
            <CardDescription>Helpful posture advice</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert className="bg-blue/20 border-blue">
                <TrendingUp className="w-4 h-4" />
                <AlertTitle>Stretch Break</AlertTitle>
                <AlertDescription>Remember to take a 5-minute stretch break every hour</AlertDescription>
              </Alert>
              <Alert className="bg-mint/20 border-mint">
                <Clock className="w-4 h-4" />
                <AlertTitle>Screen Height</AlertTitle>
                <AlertDescription>Position your screen at eye level to maintain proper neck alignment</AlertDescription>
              </Alert>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
