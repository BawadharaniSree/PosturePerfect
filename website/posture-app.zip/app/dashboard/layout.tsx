import type React from "react"
import { Navbar } from "@/components/navbar"
import { RouteGuard } from "@/components/route-guard"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <RouteGuard>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-1 container py-6">{children}</main>
      </div>
    </RouteGuard>
  )
}
