"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Edit, Save, User, Settings, Bell, LogOut } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { auth, getUserProfile, saveUserProfile } from "@/lib/firebase"
import { onAuthStateChanged, signOut } from "firebase/auth"
import { useRouter } from "next/navigation"
import { Skeleton } from "@/components/ui/skeleton"

export default function ProfilePage() {
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [userId, setUserId] = useState<string | null>(null)

  // User data state
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    age: "",
    gender: "",
    height: "",
    weight: "",
    workType: "",
  })

  // Check if user is authenticated and fetch profile data
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUserId(user.uid)

        // Set email from auth
        setUserData((prev) => ({
          ...prev,
          email: user.email || "",
          name: user.displayName || "",
        }))

        // Fetch additional profile data
        try {
          const profileData = await getUserProfile(user.uid)
          if (profileData) {
            setUserData((prev) => ({
              ...prev,
              age: profileData.age?.toString() || "",
              gender: profileData.gender || "",
              height: profileData.height?.toString() || "",
              weight: profileData.weight?.toString() || "",
              workType: profileData.workType || "",
            }))
          }
        } catch (error) {
          console.error("Error fetching profile:", error)
        } finally {
          setLoading(false)
        }
      } else {
        // Redirect to login if not authenticated
        router.push("/auth")
      }
    })

    return () => unsubscribe()
  }, [router])

  const handleEdit = () => {
    setIsEditing(!isEditing)
  }

  const handleSave = async () => {
    if (!userId) return

    setSaving(true)
    try {
      await saveUserProfile(userId, {
        name: userData.name,
        age: Number.parseInt(userData.age) || 0,
        gender: userData.gender,
        height: Number.parseInt(userData.height) || 0,
        weight: Number.parseInt(userData.weight) || 0,
        workType: userData.workType,
        updatedAt: new Date().toISOString(),
      })
      setIsEditing(false)
    } catch (error) {
      console.error("Error saving profile:", error)
    } finally {
      setSaving(false)
    }
  }

  const handleLogout = async () => {
    try {
      await signOut(auth)
      router.push("/auth")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <div className="space-y-6 page-transition">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold tracking-tight text-navy">Profile</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Personal Information</CardTitle>
                {!loading && (
                  <Button variant="ghost" size="sm" onClick={isEditing ? handleSave : handleEdit} disabled={saving}>
                    {isEditing ? (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        {saving ? "Saving..." : "Save"}
                      </>
                    ) : (
                      <>
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </>
                    )}
                  </Button>
                )}
              </div>
              <CardDescription>Update your personal details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {loading ? (
                <>
                  <div className="flex flex-col items-center gap-4 sm:flex-row">
                    <Skeleton className="h-20 w-20 rounded-full" />
                    <div className="space-y-2 w-full">
                      <Skeleton className="h-6 w-32" />
                      <Skeleton className="h-4 w-48" />
                      <div className="flex gap-2">
                        <Skeleton className="h-5 w-20" />
                        <Skeleton className="h-5 w-20" />
                      </div>
                    </div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                </>
              ) : (
                <>
                  <div className="flex flex-col items-center gap-4 sm:flex-row">
                    <Avatar className="h-20 w-20 border-2 border-blue">
                      <AvatarImage src="/placeholder.svg?height=80&width=80" alt={userData.name} />
                      <AvatarFallback>
                        <User className="h-8 w-8" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-1 text-center sm:text-left">
                      <h3 className="text-xl font-semibold text-navy">{userData.name || "User"}</h3>
                      <p className="text-sm text-muted-foreground">{userData.email}</p>
                      <div className="flex justify-center gap-2 sm:justify-start">
                        <Badge className="bg-blue text-navy">Posture Pro</Badge>
                        <Badge className="bg-mint text-navy">3-Day Streak</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={userData.name}
                        disabled={!isEditing}
                        onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={userData.email}
                        disabled={true} // Email can't be edited directly
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="age">Age</Label>
                      <Input
                        id="age"
                        type="number"
                        value={userData.age}
                        disabled={!isEditing}
                        onChange={(e) => setUserData({ ...userData, age: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender</Label>
                      <Select
                        disabled={!isEditing}
                        value={userData.gender}
                        onValueChange={(value) => setUserData({ ...userData, gender: value })}
                      >
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="non-binary">Non-binary</SelectItem>
                          <SelectItem value="prefer-not">Prefer not to say</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="height">Height (cm)</Label>
                      <Input
                        id="height"
                        type="number"
                        value={userData.height}
                        disabled={!isEditing}
                        onChange={(e) => setUserData({ ...userData, height: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        type="number"
                        value={userData.weight}
                        disabled={!isEditing}
                        onChange={(e) => setUserData({ ...userData, weight: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="workType">Work Type</Label>
                      <Select
                        disabled={!isEditing}
                        value={userData.workType}
                        onValueChange={(value) => setUserData({ ...userData, workType: value })}
                      >
                        <SelectTrigger id="workType">
                          <SelectValue placeholder="Select work type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="desk">Desk Job</SelectItem>
                          <SelectItem value="standing">Standing Job</SelectItem>
                          <SelectItem value="physical">Physical Labor</SelectItem>
                          <SelectItem value="mixed">Mixed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
            <CardFooter className="justify-between border-t pt-4">
              <Button variant="outline" onClick={() => setIsEditing(false)} disabled={loading || !isEditing}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={loading || !isEditing || saving}>
                {saving ? "Saving..." : "Save Changes"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">App Settings</CardTitle>
                <Settings className="h-5 w-5 text-blue" />
              </div>
              <CardDescription>Manage your app preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Dark Mode</h4>
                  <p className="text-sm text-muted-foreground">Toggle dark mode on or off</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Sensor Sensitivity</h4>
                  <p className="text-sm text-muted-foreground">Adjust posture detection sensitivity</p>
                </div>
                <Select defaultValue="medium">
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Select sensitivity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Auto-Sync</h4>
                  <p className="text-sm text-muted-foreground">Automatically sync data with cloud</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
            <CardFooter className="justify-end border-t pt-4">
              <Button>Save Settings</Button>
            </CardFooter>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Account Actions</CardTitle>
                <LogOut className="h-5 w-5 text-blue" />
              </div>
              <CardDescription>Manage your account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start">
                Change Password
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Export Your Data
              </Button>
              <Button variant="destructive" className="w-full justify-start" onClick={handleLogout}>
                Sign Out
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Notification Settings</CardTitle>
                <Bell className="h-5 w-5 text-blue" />
              </div>
              <CardDescription>Manage your notification preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Posture Alerts</h4>
                  <p className="text-sm text-muted-foreground">Get notified when your posture needs correction</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Daily Summary</h4>
                  <p className="text-sm text-muted-foreground">Receive a daily summary of your posture</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Achievement Notifications</h4>
                  <p className="text-sm text-muted-foreground">Get notified when you earn new achievements</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Tips & Advice</h4>
                  <p className="text-sm text-muted-foreground">Receive posture tips and advice</p>
                </div>
                <Switch />
              </div>
            </CardContent>
            <CardFooter className="justify-end border-t pt-4">
              <Button>Save Preferences</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
