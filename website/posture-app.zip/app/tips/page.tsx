import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Bookmark, BookmarkCheck, ArrowRight } from "lucide-react"
import { PostureAvatar } from "@/components/posture-avatar"

export default function TipsPage() {
  const tips = [
    {
      id: 1,
      title: "Desk Ergonomics",
      description: "Position your monitor at eye level and keep your keyboard at elbow height.",
      posture: "upright" as const,
      bookmarked: false,
    },
    {
      id: 2,
      title: "Take Regular Breaks",
      description: "Stand up and stretch every 30 minutes to prevent stiffness and improve circulation.",
      posture: "neutral" as const,
      bookmarked: true,
    },
    {
      id: 3,
      title: "Strengthen Your Core",
      description: "Regular core exercises help maintain proper posture throughout the day.",
      posture: "upright" as const,
      bookmarked: false,
    },
    {
      id: 4,
      title: "Avoid Tech Neck",
      description: "Hold your phone at eye level instead of looking down to prevent neck strain.",
      posture: "slouched" as const,
      bookmarked: false,
    },
    {
      id: 5,
      title: "Proper Sitting Position",
      description: "Keep your feet flat on the floor and maintain a 90-degree angle at your knees and hips.",
      posture: "upright" as const,
      bookmarked: true,
    },
    {
      id: 6,
      title: "Shoulder Exercises",
      description: "Roll your shoulders backward and forward to release tension and improve posture.",
      posture: "neutral" as const,
      bookmarked: false,
    },
  ]

  return (
    <div className="space-y-6 page-transition">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold tracking-tight text-navy">Posture Tips</h1>
        <p className="text-muted-foreground">Learn how to improve your posture with these helpful tips</p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {tips.map((tip) => (
          <Card key={tip.id} className="overflow-hidden shadow-sm transition-all hover:shadow-md">
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <CardTitle className="text-lg">{tip.title}</CardTitle>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  {tip.bookmarked ? <BookmarkCheck className="h-4 w-4 text-blue" /> : <Bookmark className="h-4 w-4" />}
                  <span className="sr-only">{tip.bookmarked ? "Remove bookmark" : "Bookmark tip"}</span>
                </Button>
              </div>
              <CardDescription>Posture improvement</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-start gap-4">
                <PostureAvatar posture={tip.posture} className="w-16 h-16 shrink-0" />
                <div className="space-y-2">
                  <p className="text-sm">{tip.description}</p>
                  <Button variant="link" size="sm" className="h-8 px-0 text-blue">
                    Learn more <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
