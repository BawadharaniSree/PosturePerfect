"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Logo } from "@/components/logo"

export default function SplashPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
      setTimeout(() => {
        router.push("/auth")
      }, 500)
    }, 2000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="flex items-center justify-center min-h-screen bg-beige">
      <div className={`transition-opacity duration-500 ${loading ? "opacity-100" : "opacity-0"}`}>
        <Logo className="w-32 h-32 breathing-animation" />
        <h1 className="mt-4 text-2xl font-semibold text-center text-navy">Posture Perfect</h1>
      </div>
    </div>
  )
}
